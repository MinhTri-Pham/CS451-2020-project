package cs451;
public interface Observer {
    void deliver(Message m);
}
